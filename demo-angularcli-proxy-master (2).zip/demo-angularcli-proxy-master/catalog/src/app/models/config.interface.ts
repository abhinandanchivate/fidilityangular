export interface IConfig {
  publicKey: string;
}
